### Introduction to Regression Continued

- Polynomial Regression 
- Bias vs. Variance
- Train/Test Split and Cross Validation
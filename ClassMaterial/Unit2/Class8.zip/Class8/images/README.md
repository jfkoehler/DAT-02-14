# ![](https://ga-dash.s3.amazonaws.com/production/assets/logo-9f88ae6c9c3871690e33280fcf557f33.png) 
Transformers and Preprocessing with scikit-learn

## Materials We Provide


| Topic | Description | Link |
| --- | --- | --- |
| Lesson | Transformers| [Link](./transformers-starter.ipynb)|


Scikit-learn transformers are how you change X (and y) to improve model performance. You'll learn all about them in this lesson.

---

## Additional Materials
- The scikit-learn docs are helpful.
- See the _books_ page of the Course Info repo for several recommendations.